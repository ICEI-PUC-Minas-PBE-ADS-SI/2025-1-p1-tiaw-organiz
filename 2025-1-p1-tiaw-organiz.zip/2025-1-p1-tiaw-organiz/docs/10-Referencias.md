# Referências

- ROCK CONTENT. Design para slides: como criar apresentações que impressionam. Rock Content, 2025. Disponível em: https://rockcontent.com/br/blog/design-para-slides/.

- ATLASSIAN. User stories: o que são e como escrevê-las. Atlassian, 2025. Disponível em: https://www.atlassian.com/br/agile/project-management/user-stories.
 
- 7BITS. Fluxo de usuário (user flow): o que é e como fazer. Medium, 2025. Disponível em: https://medium.com/7bits/fluxo-de-usu%C3%A1rio-user-flow-o-que-%C3%A9-como-fazer-79d965872534.
