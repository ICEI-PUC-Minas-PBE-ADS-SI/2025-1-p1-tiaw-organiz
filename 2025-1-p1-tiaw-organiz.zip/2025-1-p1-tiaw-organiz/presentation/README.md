# Apresentação do projeto

<span style="color:red">Pré-requisitos: Todos os demais artefatos</span>


## Slides

![trabalho amalia TIAW 1_page-0001](https://github.com/user-attachments/assets/396620ae-bec8-4f31-bf12-55e4c529ae30)
![trabalho amalia TIAW 1_page-0002](https://github.com/user-attachments/assets/29c454c7-8334-4d72-91d4-9a4f63097141)
![trabalho amalia TIAW 1_page-0003](https://github.com/user-attachments/assets/6d475308-baff-443f-9ef2-8ab709630c9b)
![trabalho amalia TIAW 1_page-0004](https://github.com/user-attachments/assets/1e08a617-74a0-40b4-875c-2552dbc7db77)
![trabalho amalia TIAW 1_page-0005](https://github.com/user-attachments/assets/01b655db-50d6-4a4d-a8b2-bff74a1bdf62)
![trabalho amalia TIAW 1_page-0006](https://github.com/user-attachments/assets/118d9805-b23f-4c0f-9b43-d08fdd511018)
![trabalho amalia TIAW 1_page-0007](https://github.com/user-attachments/assets/b25cc4d8-d0aa-4dcc-a63b-18dad3ca2d44)
![trabalho amalia TIAW 1_page-0008](https://github.com/user-attachments/assets/6f2a22b9-4ab9-4307-8c21-f73e11cc1a7f)
![trabalho amalia TIAW 1_page-0009](https://github.com/user-attachments/assets/efe68326-f66b-448e-954c-a44cec70ef2e)
![trabalho amalia TIAW 1_page-0010](https://github.com/user-attachments/assets/90de2000-7f0a-44ce-bf38-82180a0380a6)
![trabalho amalia TIAW 1_page-0011](https://github.com/user-attachments/assets/c838956c-1989-4f03-8946-34788902e244)
![trabalho amalia TIAW 1_page-0012](https://github.com/user-attachments/assets/25b1410a-ed2a-4788-8e6f-315fb23a6e9a)




## Vídeo

O grupo também deverá gravar um vídeo de até cinco minutos apresentando a solução. O vídeo deve incluir uma demonstração da aplicação hospedada, mostrando seu funcionamento.

Podem utilizar quaisquer recursos na produção do vídeo, mas certifiquem-se de destacar as funcionalidades da aplicação.

A seguir, estão as especificações técnicas que devem ser seguidas na criação do vídeo:

> - tamanho do arquivo limitado a 90Mb
> - taxa de FPS limitada a 30 quadros por segundo
> - resolução HD (720p) ou Full HD (1080p)
> - formato mp4.


